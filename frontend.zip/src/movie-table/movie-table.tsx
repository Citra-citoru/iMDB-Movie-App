
import React from 'react';
import { useTable, useSortBy, useFilters, useExpanded, usePagination } from 'react-table';

interface IMovies {
    Title : string,
    Year : string,
    imdbID : string,
    Type : string,
    Poster : string
}
const  MovieTable =  () => {
    return (
        <div>Test</div>
    );
}
export default MovieTable;
